== French Accents Wordpress Plugin ==
Contributors: hereladrastel
Tags: french, accents, tinymce, post
Tested up to: 4.9.7
Stable Tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
French Accents adds the majuscule accents on the text editor. Some majuscule characters such as É, È, À, Ç, œ, or Ù cannot be typed on a french keyboard. The plugin adds for each character a button in the text editor to type them.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress

== Screenshots ==
1. Plugin in action at post editor section

== Frequently Asked Questions ==
= I have a suggestion, a bug, or anything else =
Write me an email at hereladrastel@gmail.com. I'll answer as soon as possible.

== Changelog ==
= 1.0 =
* First version